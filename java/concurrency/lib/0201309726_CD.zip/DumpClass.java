/** A shortcut to COM.sootNsmoke.oolong.DumpClass for easy use on a command line */
public class DumpClass
{
    public static void main(String a[])
    {
	COM.sootNsmoke.oolong.DumpClass.main(a);
    }
}
