/** A shortcut to COM.sootNsmoke.oolong.Oolong for easy use on a command line */
public class Oolong
{
    public static void main(String a[])
    {
	COM.sootNsmoke.oolong.Oolong.main(a);
    }
}
