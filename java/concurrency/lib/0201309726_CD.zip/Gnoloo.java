/** A shortcut to COM.sootNsmoke.oolong.Gnoloo for easy use on a command line */
public class Gnoloo
{
    public static void main(String a[])
    {
	COM.sootNsmoke.oolong.Gnoloo.main(a);
    }
}
